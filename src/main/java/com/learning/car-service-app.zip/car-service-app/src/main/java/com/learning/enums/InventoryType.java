package com.learning.enums;

public enum InventoryType {
    EXTERNAL,INTERNAL
}
